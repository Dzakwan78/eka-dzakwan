import { useState } from 'react'
import './App.css'
import Book from './components/Book'  // Mengganti nama komponen menjadi Book


function App() {
  return (
    <>
      {/* Menampilkan komponen Book yang berisi daftar buku */}
      <Book />
    </>
  )
}

export default App
