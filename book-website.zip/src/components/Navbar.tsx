function Navbar() {
  return (
    <div>
      ini navbar Bapak
    </div>
  )
}

export default Navbar
