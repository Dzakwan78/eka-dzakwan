// InterBook.ts
export interface InterBook {
    id: string; // or number, depending on your API
    title: string;
    url: string; // Link to the book's main page
    coverImage: string; // URL to the book cover image
    author: string; // Author of the book
    publicationDate: string; // Publication date
    description: string; // Brief description of the book
    detailsUrl: string; // Link to the book's detail page
}